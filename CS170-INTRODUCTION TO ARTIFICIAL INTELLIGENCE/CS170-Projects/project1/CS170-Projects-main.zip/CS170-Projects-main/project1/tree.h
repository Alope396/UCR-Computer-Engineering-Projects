#ifndef __Tree_H__
#define __Tree_H__

#include "node.h"

using namespace std;

// enum SEARCH_METHODS {
//     UNIFORM_COST,
//     A_STAR_MISPLACED_TILE_H,
//     A_STAR_EUCLIDEAN_DIST_H
// };

class Tree {
    private:
        Node* root;

        //might not need these functions
        
        Node* search(Node* , vector<vector<Tile>> key) const;
        /*void remove(Node* ) const;
        int getHeight(Node* ) const;

        void preOrder(Node* ) const;
        void inOrder(Node* ) const;
        void postOrder(Node* ) const;
        */

    public:
        Tree(Node* root);
        ~Tree(); //destructor - remove all nodes in tree

        Node* get_root() const;
        void set_root(Node* root);
        
        //int height(const string &) const; //depth of node
        bool search(vector<vector<Tile>> key) const; //search for node with the correct key
        void insert(Node* node, vector<vector<Tile>> state); //insert node to tree - might not need
        //void remove(const string &); //remove node from tree - might not need

        //iteratng through tree nodes
        /*void preOrder() const;
        void inOrder() const;
        void postOrder() const;
        */
};
#endif