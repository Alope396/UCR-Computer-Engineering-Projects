#include <queue>
#include <functional>
#include "tree.h"

Tree::Tree(Node* root) {
    this->root = root;
}

Tree::~Tree() {
    delete root;
}

Node* Tree::get_root() const {
    return root;
}

void Tree::set_root(Node* root) {
    this->root = root;
}

void Tree::insert(Node* node, vector<vector<Tile>> state) {
    //add new node with state to current node's children
    int child_depth_level = node->get_depth_level() + 1;
    Node* child = new Node(state, child_depth_level);
    node->add_children(child);
}

Node* search(Node* node, vector<vector<Tile>> key) const {
    Tree tree = new Tree(node);
    /**
     * @brief Priority queue for frontier
     * Node - comparison object
     * vector<Node> - container
     * std::greater<Node> - comparison function
     */
    priority_queue<Node, vector<Node>, std::greater<Node>> frontier;
    frontier.push(node&);

    while(!frontier.empty()) {
        //pop node from frontier
        const Node* curr_node = &(frontier.top());
        frontier.pop();

        //check if node is goal node
        if(curr_node->get_state() == key) {
            return curr_node;
        }
        frontier.add_children(curr_node->get_children());
        //frontier.add_children(expand(curr_node)))
    }

    // return failure if frontier is empty
    return nullptr;
}